# Windows 11 Fix Package

## Contents
| File | Purpose |
|------|---------|
| `Launch-Fix.bat` | **Start here.** Double-click this to run everything. |
| `Run-Fix.ps1`    | PowerShell script that performs all seven steps. |
| `fix-log.txt`    | Created on run — full timestamped log. |
| `kir-install.log`| Created on run — verbose MSI install log. |

## What it does (in order)

1. **Enables PS Remoting** — runs `Enable-PSRemoting -Force`
2. **Disables Windows Update auto-update** — sets registry policy keys under `HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU` and disables the `wuauserv`, `UsoSvc`, and `WaaSMedicSvc` services.
3. **Uninstalls KB5085516** — runs `wusa /uninstall /kb:5085516 /quiet /norestart`
4. **Downloads & installs the Known Issue Rollback MSI** — downloads from Microsoft's CDN and installs silently with a verbose log.
5. **Sets KIR Group Policy to Disabled** — writes the registry key for `Local Computer Policy > Administrative Templates > KB5065426 250923_06201 Known Issue Rollback` to Disabled (value=0), then runs `gpupdate /force`.
6. **Configures SMB Client** — sets `RequireSecuritySignature = $false` and `EnableInsecureGuestLogins = $true` via `Set-SmbClientConfiguration`.
7. **Prompts to restart** — offers an immediate restart (10-second countdown) or the option to restart manually later.

## How to run

1. Copy the `WindowsFix` folder to the target Windows 11 machine.
2. Double-click **`Launch-Fix.bat`**.
3. Click **Yes** on the UAC prompt.
4. Wait for all steps to complete, then choose to restart now or later.

## Requirements
- Windows 11 (24H2 / 25H2) or Windows Server 2025
- Internet access (for the MSI download in step 4)
- Administrator account

## Notes
- The batch file uses `-ExecutionPolicy Bypass` scoped to the single session — it does **not** permanently change the machine execution policy.
- If the MSI download fails (e.g. no internet), the script will exit and log the direct URL so you can download it manually and re-run.
- Exit code `3010` from wusa or msiexec means "success, reboot needed."
- The SMB guest login setting (`EnableInsecureGuestLogins`) allows connections to shares without authentication — only use on trusted networks.
