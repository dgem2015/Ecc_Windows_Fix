@echo off
:: ============================================================
:: Windows Fix Launcher
:: Elevates to Administrator and runs Run-Fix.ps1
:: ============================================================

title Windows Fix Launcher

:: Check if already running as Administrator
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :RunScript
)

:: Not elevated — re-launch with elevation
echo Requesting Administrator privileges...
powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:RunScript
echo.
echo  ==========================================
echo   Windows 11 Fix Script
echo   Running as Administrator
echo  ==========================================
echo.

:: Set working directory to script location
cd /d "%~dp0"

:: Temporarily allow script execution for this session only
powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0Run-Fix.ps1"

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Script exited with error code %errorlevel%.
    echo  Check fix-log.txt for details.
    pause
) else (
    echo.
    echo  Script completed. Check fix-log.txt for a full log.
)
