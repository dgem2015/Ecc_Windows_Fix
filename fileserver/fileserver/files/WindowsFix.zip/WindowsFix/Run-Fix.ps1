#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Windows 11 Fix Script
    - Enables PS Remoting
    - Disables Windows Update auto-update
    - Uninstalls KB5085516
    - Downloads and installs Known Issue Rollback MSI
#>

$ErrorActionPreference = "Stop"
$logFile = "$PSScriptRoot\fix-log.txt"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry = "[$timestamp] [$Level] $Message"
    Write-Host $entry
    Add-Content -Path $logFile -Value $entry
}

Write-Log "===== Windows Fix Script Started ====="

# -------------------------------------------------------
# STEP 1: Enable PowerShell Remoting
# -------------------------------------------------------
Write-Log "STEP 1: Enabling PowerShell Remoting..."
try {
    Enable-PSRemoting -Force
    Write-Log "PowerShell Remoting enabled successfully."
} catch {
    Write-Log "WARNING: PSRemoting step encountered an issue: $_" "WARN"
}

# -------------------------------------------------------
# STEP 2: Disable Windows Update Auto-Update
# -------------------------------------------------------
Write-Log "STEP 2: Disabling Windows Update auto-update..."
try {
    # Disable via registry
    $auPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
    if (-not (Test-Path $auPath)) {
        New-Item -Path $auPath -Force | Out-Null
    }
    Set-ItemProperty -Path $auPath -Name "NoAutoUpdate"       -Value 1 -Type DWord -Force
    Set-ItemProperty -Path $auPath -Name "AUOptions"          -Value 1 -Type DWord -Force
    Set-ItemProperty -Path $auPath -Name "NoAutoRebootWithLoggedOnUsers" -Value 1 -Type DWord -Force

    # Also disable Windows Update services
    $services = @("wuauserv", "UsoSvc", "WaaSMedicSvc")
    foreach ($svc in $services) {
        try {
            Stop-Service  -Name $svc -Force -ErrorAction SilentlyContinue
            Set-Service   -Name $svc -StartupType Disabled -ErrorAction SilentlyContinue
            Write-Log "  Service '$svc' stopped and disabled."
        } catch {
            Write-Log "  Could not fully disable service '$svc': $_" "WARN"
        }
    }
    Write-Log "Windows Update auto-update disabled successfully."
} catch {
    Write-Log "ERROR disabling Windows Update: $_" "ERROR"
}

# -------------------------------------------------------
# STEP 3: Uninstall KB5085516
# -------------------------------------------------------
Write-Log "STEP 3: Uninstalling KB5085516 via wusa..."
try {
    $wusaArgs = "/uninstall /kb:5085516 /quiet /norestart"
    $proc = Start-Process -FilePath "wusa.exe" -ArgumentList $wusaArgs `
                          -Wait -PassThru -NoNewWindow
    $exitCode = $proc.ExitCode
    switch ($exitCode) {
        0       { Write-Log "KB5085516 uninstalled successfully (exit 0)." }
        3010    { Write-Log "KB5085516 uninstalled; reboot required (exit 3010)." "WARN" }
        2359303 { Write-Log "KB5085516 not found on this system (may already be removed)." "WARN" }
        default { Write-Log "wusa exited with code $exitCode." "WARN" }
    }
} catch {
    Write-Log "ERROR running wusa: $_" "ERROR"
}

# -------------------------------------------------------
# STEP 4: Download and Install Known Issue Rollback MSI
# -------------------------------------------------------
Write-Log "STEP 4: Downloading Known Issue Rollback MSI..."
$msiUrl  = "https://download.microsoft.com/download/c6c70455-59ce-4d47-b13c-56b99d0435f1/Windows%2011%2024H2,%20Windows%2011%2025H2%20and%20Windows%20Server%202025%20KB5065426%20250923_06201%20Known%20Issue%20Rollback.msi"
$msiPath = "$PSScriptRoot\KIR_KB5065426.msi"

try {
    Write-Log "  Downloading from Microsoft..."
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $webClient = New-Object System.Net.WebClient
    $webClient.DownloadFile($msiUrl, $msiPath)
    Write-Log "  Download complete: $msiPath"
} catch {
    Write-Log "ERROR downloading MSI: $_" "ERROR"
    Write-Log "  Please manually download from:" "WARN"
    Write-Log "  $msiUrl" "WARN"
    exit 1
}

Write-Log "STEP 4b: Installing Known Issue Rollback MSI..."
try {
    $msiArgs = "/i `"$msiPath`" /quiet /norestart /l*v `"$PSScriptRoot\kir-install.log`""
    $proc = Start-Process -FilePath "msiexec.exe" -ArgumentList $msiArgs `
                          -Wait -PassThru -NoNewWindow
    $exitCode = $proc.ExitCode
    switch ($exitCode) {
        0    { Write-Log "MSI installed successfully (exit 0)." }
        3010 { Write-Log "MSI installed; reboot required to complete (exit 3010)." "WARN" }
        default { Write-Log "msiexec exited with code $exitCode. Check kir-install.log." "WARN" }
    }
} catch {
    Write-Log "ERROR installing MSI: $_" "ERROR"
    exit 1
}

# -------------------------------------------------------
# STEP 5: Set Known Issue Rollback Group Policy to Disabled
# -------------------------------------------------------
Write-Log "STEP 5: Setting KIR Group Policy (KB5065426 250923_06201) to Disabled..."
try {
    # The KIR MSI registers its policy under this GUID-based registry path.
    # The GUID below is the standard KIR namespace for KB5065426 250923_06201.
    $kirBase = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\KB5065426 250923_06201 Known Issue Rollback"

    if (-not (Test-Path $kirBase)) {
        New-Item -Path $kirBase -Force | Out-Null
        Write-Log "  Created registry key: $kirBase"
    }

    # Setting the policy value to 0 maps to "Disabled" for KIR policies.
    Set-ItemProperty -Path $kirBase -Name "KB5065426 250923_06201 Known Issue Rollback" `
                     -Value 0 -Type DWord -Force
    Write-Log "  Policy set to Disabled (value=0) at:"
    Write-Log "  $kirBase"

    # Force a Group Policy refresh so the setting takes effect immediately
    Write-Log "  Refreshing Group Policy..."
    $gp = Start-Process -FilePath "gpupdate.exe" -ArgumentList "/force" `
                        -Wait -PassThru -NoNewWindow
    Write-Log "  gpupdate exited with code $($gp.ExitCode)."
    Write-Log "KIR Group Policy set to Disabled successfully."
} catch {
    Write-Log "ERROR setting KIR Group Policy: $_" "ERROR"
}

# -------------------------------------------------------
# STEP 6: Configure SMB Client Security Settings
# -------------------------------------------------------
Write-Log "STEP 6: Configuring SMB Client settings..."
try {
    Write-Log "  Setting RequireSecuritySignature = False..."
    Set-SmbClientConfiguration -RequireSecuritySignature $false -Force
    Write-Log "  RequireSecuritySignature set to False."

    Write-Log "  Setting EnableInsecureGuestLogins = True (via registry)..."
    # Set-SmbClientConfiguration -EnableInsecureGuestLogins is not available on all builds.
    # Write directly to the registry instead — this is equivalent and universally supported.
    $lanmanPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
    Set-ItemProperty -Path $lanmanPath -Name "AllowInsecureGuestAuth" -Value 1 -Type DWord -Force
    Write-Log "  EnableInsecureGuestLogins set to True (AllowInsecureGuestAuth=1)."

    Write-Log "SMB Client configuration updated successfully."
} catch {
    Write-Log "ERROR configuring SMB Client: $_" "ERROR"
}

# -------------------------------------------------------
# STEP 7: Prompt to Restart
# -------------------------------------------------------
Write-Log "===== All steps completed. See fix-log.txt for details. ====="
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  All steps completed successfully!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  A restart is required to finalize all changes." -ForegroundColor Yellow
Write-Host ""
Write-Host "  [R] Restart now" -ForegroundColor White
Write-Host "  [Q] Quit (restart manually later)" -ForegroundColor White
Write-Host ""

do {
    $choice = Read-Host "Enter your choice (R/Q)"
    $choice = $choice.Trim().ToUpper()
} while ($choice -ne "R" -and $choice -ne "Q")

if ($choice -eq "R") {
    Write-Log "User chose to restart now. Restarting in 10 seconds..."
    Write-Host ""
    Write-Host "Restarting in 10 seconds... Close this window to cancel." -ForegroundColor Yellow
    Start-Sleep -Seconds 10
    Restart-Computer -Force
} else {
    Write-Log "User chose to restart later."
    Write-Host ""
    Write-Host "Please restart this machine manually to complete the changes." -ForegroundColor Yellow
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
